java -jar TDDT.jar
